M.U.G.E.N Large-capacity select screen
--------------------------------------

M.U.G.E.N       (c) 2002 Elecbyte
                www.elecbyte.com


Released: 2 April 2001
For MUGEN version 2002.04.14

This motif gives you up to 60 slots for characters.
Place the contents of this archive in a new directory under
data/ called big. You should now have system.def in data/big/.

To use this motif, type:

  mugen -r big

Optionally, you can make a new character roster for this motif.
Simply copy select.def from the data/ directory into data/big/,
and edit data/big/select.def accordingly.
